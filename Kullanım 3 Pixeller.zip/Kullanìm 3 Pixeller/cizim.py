import cv2
import numpy as np
import matplotlib.pyplot as plt

resim=cv2.imread("resim.png")
plt.imshow(resim)
plt.show()

