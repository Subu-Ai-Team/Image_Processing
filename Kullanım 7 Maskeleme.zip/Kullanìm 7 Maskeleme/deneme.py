import cv2
import numpy as np
import matplotlib.pyplot as plt


img=cv2.imread("saturn-mars_16_9_1571640926.jpg")

cv2.imshow("saturn",img)

resim=img.shape
print(resim)










cv2.waitKey()
cv2.destroyAllWindows()