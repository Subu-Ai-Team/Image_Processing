import cv2
import numpy as np
import matplotlib.pyplot as plt

resim=cv2.imread("a.jpg")
plt.imshow(resim)



