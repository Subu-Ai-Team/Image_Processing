import cv2 as cv

#Get and show images
img1 = cv.imread('red.jpg')
#cv.imshow('red',img1)    cv.waitKey(5000)
img2 = cv.imread('moon.jpg')
#cv.imshow('moon',img2)    cv.waitKey(5000)

img_1_shape = img1.shape
img_2_shape = img2.shape
print(img_1_shape,img_2_shape)

roi = img1[0:img_2_shape[0],0:img_2_shape[1]]
print(roi.shape)
#cv.imshow("roi",roi)   cv.waitKey(5000)

img2gray = cv.cvtColor(img2,cv.COLOR_BGR2GRAY)
#print(img2gray.shape) cv.imshow('img2gray',img2gray)

threshold, mask = cv.threshold(img2gray, 10, 255, cv.THRESH_BINARY)
#cv.imshow("mask",mask)   cv.waitKey(5000)
mask_inv = cv.bitwise_not(mask)
#cv.imshow("mask_inv",mask_inv)  cv.waitKey(5000)

# Now black-out the area of moon in ROI
img1_bg = cv.bitwise_and(roi, roi, mask = mask_inv)
#cv.imshow("img1_bg",img1_bg) cv.waitKey(5000)

# Take only region of moon from moon image.
img2_fg = cv.bitwise_and(img2, img2, mask = mask)
#cv.imshow("img2_fg",img2_fg)  cv.waitKey(10000)


# Put moon in ROI and modify the main image
added = cv.add(img1_bg,img2_fg) 
#cv.imshow('added',added)  cv.waitKey(5000)

img1[0:img_2_shape[0], 0:img_2_shape[1]] = added
cv.imshow('res',img1)

cv.waitKey(10000)
cv.waitKey(1)
cv.destroyAllWindows()
cv.waitKey(1)



