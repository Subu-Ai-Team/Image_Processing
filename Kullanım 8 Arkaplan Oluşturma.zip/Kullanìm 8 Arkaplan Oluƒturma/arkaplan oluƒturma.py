import cv2
import numpy as np
"""
arkaplan1 = np.zeros((500,500,3))
cv2.imshow("Once",arkaplan1)

arkaplan2 = np.ones((500,500,3))
cv2.imshow("write_background",arkaplan2)

arkaplan3 = np.zeros((500,500,3))

#cv2.imshow("3",arkaplan3)

for i in range(500):
    for j in range(500):
        arkaplan3[i,j] = [260,60,50] #[b,g,r]
cv2.imshow("colors_backround",arkaplan3)

arkaplan1[:] = [255,0,0]
cv2.imshow("Sonra",arkaplan1)
"""

#cv2.namedWindow("Display", cv2.WINDOW_NORMAL)  # boş bir pencere oluştur
#cv2.namedWindow("Display1", cv2.WINDOW_AUTOSIZE)
#cv2.namedWindow("Display2", cv2.WINDOW_FULLSCREEN )
#cv2.resizeWindow("Display", 480, 270)

empty = np.empty((400,400))

cv2.imshow("bos",empty)

#cv2.imshow("2",arkaplan2)
#cv2.imshow("3",arkaplan3)



cv2.waitKey()
cv2.destroyAllWindows()