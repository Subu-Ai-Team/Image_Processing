import cv2
import numpy as np
import matplotlib.pyplot as plt


###################################################
arkaplan = cv2.imread("resim.png")
logo = cv2.imread("sau.png")
griLogo = cv2.imread("sau.png",0)
cv2.imshow("original",logo)
###################################################

# logoyu tek kanallı gri hale getirir.
logo_gri=cv2.cvtColor(logo,cv2.COLOR_BGR2GRAY)
plt.imshow(logo_gri,cmap="gray")
plt.show()
#resmi tek kanal (Gri) hale getirme;
#logo_gri = cv2.cvtColor(griLogo,cv2.COLOR_BGR2GRAY)

############################################################
# maskleme işlemi resmi ayırmak için kullanılıyor.
# ret =eşik değeri 
# maske seçtiğim değerin üstü beyaz altını siyah yapar 
# 1) tek kanallı
#2) pixeller yumuşak geçmiyor 
# 3)2 farklı pixel değeri var 
min = 100

ret,maske = cv2.threshold(griLogo,min,255,cv2.THRESH_BINARY)
#min değerin üstündeki pixelleri 255 değerinde (beyaz) yap
#min değerin altındakileri de 0 değerinde yap yani siyah yap.
print(ret)
cv2.imshow("Mask",maske)

#############################################################
boy, genişlik = griLogo.shape
print(boy,genişlik)


#eğer resim sadece iki farklı pixellerden oluşsaydı
#pixelleri şöyle bulabilirdik;
#resimde bulunan pixelleri bulma 
liste = []
for i in range(griLogo.shape[0]):
    for j in range(griLogo.shape[1]):
        if griLogo[i,j] not in liste:
            liste.append(griLogo[i,j])

print(liste)
print(len(liste))

#############################################################



# uyumlu eşik fonksiyonu (arkaplandan ayrışması zor olan nesnelerde kullanılabilir)
maske2 = cv2.adaptiveThreshold(griLogo,255,cv2.ADAPTIVE_THRESH_MEAN_C,cv2.THRESH_BINARY,11,8)
cv2.imshow("maske2",maske2)
#cv2.ADAPTIVE_THRESH_MEAN_C : Eşik Değeri = (Komşu alan değerlerinin ortalaması – sabit değer).
# Başka bir deyişle, bir nokta eksi sabitinin blockSize×blockSize komşuluğunun ortalamasıdır.

#cv2.ADAPTIVE_THRESH_GAUSSIAN_C : Eşik Değeri = (Mahalle değerlerinin Gauss ağırlıklı toplamı – sabit değer).
# Başka bir deyişle, bir nokta eksi sabitinin blockSize×blockSize komşuluğunun ağırlıklı toplamıdır.

#blockSize  = Bir eşik değeri hesaplamak için kullanılan piksel komşusunun boyutu=11
#sabit=Komşu piksellerin ortalama veya ağırlıklı toplamından çıkarılan sabit bir değer
#11 boyutlu kareler ile 8 constant değerinde eşik ortalamaları al ve maskele


#farklı threshold metotları, alternatif denenebilir;
#ret,maske = cv2.threshold(griLogo,min,255,cv2.THRESH_TRUNC)
#ret,maske = cv2.threshold(griLogo,min,255,cv2.THRESH_TOZERO)


mask_inverse = cv2.bitwise_not(maske) #0'ları 255, 255'leri 0 yap.
#bit_and eşleştirmesi:  -------------------------------------------

bolge = arkaplan[0:boy,0:genişlik]
entegre1 = cv2.bitwise_and(bolge,bolge,mask=maske)
arkaplan[0:boy,0:genişlik] = entegre1 
cv2.imshow("Arkaplan Uzeri siyah Logo",entegre1)
cv2.imshow("Son Hal",arkaplan)

#cv2.waitKey()
#cv2.destroyAllWindows()

#Bolge ile maskenin pixel bitlerini AND türünde eşleştir"""
#beyaz arkaplanı olan maske ile arkaplandaki pixel eşleri için;"""
#background(10111001) and beyaz(11111111) = sonuç(10111001) yani arkaplan korundu"""
#background(10111001) and siyah(00000000) = sonuç(00000000) yani siyah nesne korundu"""


cv2.imshow("Ters Mask",mask_inverse)
entegre2 = cv2.bitwise_and(bolge,bolge,mask=mask_inverse)
arkaplan[0:boy,0:genişlik] = entegre2

cv2.imshow("Nesne icinde arkaplan",entegre2)

"""Eğer siyah arkaplanı olan maske ile bolge eşleştirilirse"""
"""Bu sefer nesne içine arkaplan oluşur"""
# -----------------------------------------------------------------

#Eğer entegre1 ile arkaplanı siyah, kendisi renkli olan resim add ile toplanırsa;
#Siyah pixel 0 değerinde olduğundan eklendiği pixel değerini direk alır
#arkaplan üstüne renkli entegre yapılmış olur.
#renkli_entegre = cv2.add(entegre1,LogoOnBlack)

#parça alma 

cv2.imshow("Son Hal",arkaplan)

cv2.waitKey()
cv2.destroyAllWindows()