import cv2
import numpy as np
import matplotlib.pyplot as plt
resim = np.ones((500,600,3))# boyutlar tuple içinde verilmeli
#resim_resized=cv2.resize(resim,(200,200))
#cv2.imshow("resim",resim_resized ) 
plt.imshow(resim)
string = "SUBU-AI"
#plt.imshow(resim)
#h,w,c=resim.shape #print(h,w,c) #a=int(h/2) #b=int(w/2) #print(a,b),#loc1=(a,b)

loc = (150,200) #sol alt köşesinin konumu
scale = 7
color = [0,0,0]
cv2.putText(resim,string,loc,cv2.FONT_ITALIC,scale,color)

cv2.imshow("resim",resim)
cv2.waitKey()
cv2.destroyAllWindows()

